# Danh sách sản phẩm

Bài thực hành HTML sử dụng các thẻ `table`, `tr`, `th`, `td`.

## Chạy
Mở `index.html` bằng trình duyệt web.
